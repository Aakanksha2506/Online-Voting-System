<html>
    <head>
        <title>Online Voting System - Dashboard</title>
</head>
<body>
    <h1>Online Voting System</h1>
    <hr>
</body>
</html>


